jQuery(document).ready(function() {
	jQuery(".main-navigation").addClass("js").before('<div id="menu"><i class="fa fa-bars"></i> Menu</div>');
	jQuery("#menu").click(function(){
		jQuery(".main-navigation").slideToggle({
            duration: 400
        });
        //$("#nav").slideDown( "slow" );
	});
	jQuery(window).resize(function(){
		if(window.innerWidth > 768) {
			jQuery(".main-navigation").removeAttr("style");
		}
	});
});