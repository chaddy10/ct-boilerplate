<?php
/*
Plugin Name: AC Responsive Nav
Plugin URI: 
Description: A fully responsive navigation for Wordpress Sites.
Version: 1.0
Author: Andrew Chadwick
Author URI: 
*/
 
function ac_add_nav_script() {
	// Mobile Navigation Script
	wp_register_script( 'script-js',  plugins_url( 'script.js', __FILE__ ), array('jquery'),''  );
	wp_enqueue_script( 'script-js' );
	
	// Stylesheet for responsive navigation
	wp_enqueue_style( 'ac-mobile-nav-style', plugins_url( 'css/ac-mobile-nav.css', __FILE__ ), '', null );
}
add_action( 'wp_enqueue_scripts', 'ac_add_nav_script' );